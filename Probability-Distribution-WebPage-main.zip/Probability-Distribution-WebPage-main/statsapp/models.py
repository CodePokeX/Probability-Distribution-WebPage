from django.db import models
# No models needed
