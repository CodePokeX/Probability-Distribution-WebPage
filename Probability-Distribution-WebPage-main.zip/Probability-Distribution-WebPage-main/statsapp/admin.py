from django.contrib import admin
# No models to register
